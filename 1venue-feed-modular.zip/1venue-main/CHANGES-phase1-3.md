# 1venue: Phase 1–3 changes

Three phases: **(1)** survive restarts and keep memory bounded, **(2)** move heavy services
(LiveKit, speech-to-text) off the app, **(3)** restructure into feature folders so a team can
work in parallel. Nothing here has been deployed. Read "Before you deploy" first, and the
last section, **"1venue on its own: own accounts, email, Google, new domain"**, which changes
sign-in for everyone.

---

## Before you deploy (manual steps)

Do these in order. Steps 1–3 are needed for this release; 4–6 can follow.

### 1. Coolify env vars for the 1venue app

Add (or check) these on the 1venue application. Secrets you already have stay as they are.

| Variable | Value | Why |
|---|---|---|
| `NODE_MAX_OLD_SPACE_MB` | `2048` | Node heap (was a fixed 384 MB). Use about 65% of the container memory. |
| Coolify → Resource limits → Maximum memory | `3g` (`APP_MEM_LIMIT` when you use docker compose) | Keep about 1 GB above the heap |
| `CHAT_INLINE_MAX_MB` | `0` (default) | Chat attachments always go through `/api/files` |
| `MEETING_RESTORE_MAX_MINUTES` | `30` (default) | How long a saved meeting can wait for its people after a restart |
| `LEFT_PARTICIPANT_PRUNE_MINUTES` | `10` (default) | Forget people who left a meeting |
| Health check path | `/health` | Liveness only; use `/ready` for uptime monitors (it checks the database) |

Everything else has safe defaults; see the new sections at the top of `.env.example`. If
Coolify lets you set a stop timeout for the container, keep it at **15 s or more** (the app needs about 2 s, and
force-exits at 8 s).

### 2. Deploy timing

* The first deploy of this release still runs the **old** code's shutdown, which ends live
  meetings. Deploy it outside meeting hours. From the next deploy on, meetings survive.
* While a Coolify LiveKit resource still builds from `docs/livekit` in this repo, every push to
  `main` may redeploy LiveKit too, which drops calls for a few seconds. Step 4 fixes that.
* The database migration (`meeting_snapshots` table) runs automatically on boot.

### 3. Cloudflare R2 for uploads (recommended)

1. Cloudflare dashboard → **R2** → Create bucket, e.g. `1venue-uploads`, location Automatic.
2. R2 → **Manage API tokens** → Create token: *Object Read & Write*, limited to that bucket.
   Copy the Access Key ID and Secret Access Key (shown once).
3. R2 → Overview: copy your **S3 API** endpoint `https://<ACCOUNT_ID>.r2.cloudflarestorage.com`.
4. Optional, faster downloads: bucket → Settings → **Custom domain**, e.g. `files.1venue.live`.
5. On the 1venue app in Coolify set:
   ```
   STORAGE_DRIVER=s3
   S3_ENDPOINT=https://<ACCOUNT_ID>.r2.cloudflarestorage.com
   S3_REGION=auto
   S3_BUCKET=1venue-uploads
   S3_ACCESS_KEY_ID=…
   S3_SECRET_ACCESS_KEY=…
   S3_FORCE_PATH_STYLE=true
   S3_PUBLIC_BASE_URL=https://files.1venue.live   # only if you did step 4
   ```
6. Existing files stay on the `/data` volume and keep working: each file row remembers which
   storage it was saved to, so old files are still served from `/data` and only new uploads go
   to R2. **Keep the `/data` mount.** (Moving old files to R2 would also need their database rows
   updated; not part of this release.)

Without `S3_PUBLIC_BASE_URL`, downloads are streamed through the app (no longer loaded fully
into memory first).

### 4. LiveKit on its own repo (and later its own VPS)

Full guide: `livekit-server/README.md`. Short version:

1. Push `livekit-server/` to a new Git repo.
2. DNS: `rtc.1venue.live` A record → the LiveKit server's IP, **DNS only (grey cloud)**.
   Optional TURN/TLS needs a second name, e.g. `turn.1venue.live`, also grey cloud.
3. Firewall on that server (ufw **and** Contabo's firewall if you use it): 80/tcp, 443/tcp,
   7881/tcp, 50000–60000/udp, 3478/udp, 30000–30100/udp. Do not open 7880.
4. Keys: `./scripts/generate-keys.sh` (or reuse the current pair so only `LIVEKIT_URL` changes in 1venue).
5. Coolify: new **Docker Compose** resource from the repo; env `LIVEKIT_KEYS="APIkey: secret"`,
   `NODE_IP=<public IPv4>`, `LIVEKIT_DOMAIN=rtc.1venue.live`; domain on the `livekit` service
   `https://rtc.1venue.live:7880`. If Coolify won't attach a domain to a host-network service,
   use Option B in the README (Traefik dynamic config).
6. Stop the old LiveKit resource, deploy the new one, run
   `./scripts/check.sh rtc.1venue.live <key> <secret>`, join a room from Wi-Fi and from mobile data.
7. 1venue env: `LIVEKIT_URL=wss://rtc.1venue.live`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET`.

Contabo sizing: a Cloud VPS 20/30 (6–8 vCPU) is a good dedicated LiveKit box. LiveKit is CPU and
bandwidth bound, not RAM bound.

### 5. Speech-to-text (RunPod or hosted)

The STT sidecar no longer runs inside the app's compose file (it is a 3 GB CPU model that
competed with meetings). Pick one, set it on the 1venue app, and restart:

* **Cheapest hosted:** Groq. `STT_SECONDARY_BASE_URL=https://api.groq.com/openai/v1`,
  `STT_SECONDARY_MODEL=whisper-large-v3-turbo`, `STT_SECONDARY_API_KEY=<groq key>`.
* **OpenAI:** `STT_SECONDARY_BASE_URL=https://api.openai.com/v1`, `STT_SECONDARY_MODEL=whisper-1`.
* **RunPod GPU pod** (your own Whisper, pay per hour): deploy a pod from the image
  `ghcr.io/speaches-ai/speaches:latest-cuda`, expose HTTP port 8000, then
  `STT_PRIMARY_BASE_URL=https://<POD_ID>-8000.proxy.runpod.net/v1`,
  `STT_PRIMARY_MODEL=Systran/faster-whisper-large-v3`, `STT_PRIMARY_API_KEY=<any non-empty>`.
  Stop the pod when you have no events: it bills while running.
* **N-ATLaS (Nigerian-accent models)** on a separate box: `docker compose -f stt-sidecar/docker-compose.yml up -d --build`
  (needs `HF_TOKEN` and accepted model terms), then `STT_PRIMARY_BASE_URL=http://<box>:8000/v1`.
* Nothing set: captions fall back to the browser's Web Speech API, as before.

### 6. GitHub for the team

* Replace the `@LEAD_MAINTAINER` / `@DEV_*` placeholders in `.github/CODEOWNERS`.
* Branch protection on `main`: require a PR, 1 approval, review from Code Owners, and the
  **CI / test** check (`.github/workflows/ci.yml` runs `npm test` against Postgres 16).

---

## Phase 1: restarts, memory, storage

**Restarts no longer end meetings**
* On `SIGTERM` the app saves every live meeting to the new `meeting_snapshots` table
  (participants, roles, chat, polls, Q&A, stage, whiteboards, content, security settings; timers
  dropped), tells browsers `server-restarting`, closes sockets with code 1012, and exits.
* The new process restores a meeting the first time anyone touches it (WebSocket register,
  `/api/join`, `/api/meeting/:code`, `/api/livekit-token`). Lazy restore matters because Coolify
  starts the new container before stopping the old one.
* Browsers show a "Reconnecting…" banner and rejoin automatically with fast, jittered retries.
  Audio/video keep flowing because LiveKit is separate.
* Snapshots older than 30 minutes are ended properly (history closed, event marked ended).
* Creating a meeting with a code that has an old snapshot discards it first.
* Files: `src/rooms/snapshot.js`, `src/index.js`, `src/ws/hub.js`, `src/http/…`, `public/js/room/room.js`,
  `migrations/20261113000000_meeting_snapshots.sql`.

**Memory**
* Heap is configurable (`NODE_MAX_OLD_SPACE_MB`, default 2048, was 384). Compose `mem_limit`
  is 3g for the app and 1g for Postgres (`shared_buffers` 256 MB).
* WebSocket heartbeat every 30 s; dead sockets are terminated.
* People who left more than 10 minutes ago are pruned from meeting memory (hosts/co-hosts kept).
* Whiteboard: max 1000 strokes per room, 2000 points per stroke (was 2000 strokes and 4000 points);
  when full, the oldest 25% are dropped. Shared-board frames are capped the same way.
* Screen timeline: max 10 items (as before) and a new 1.5 MB cap per snapshot.
* Inline `data:` chat attachments are off (were allowed up to 0.6 MB over the WebSocket). The
  current client already uploads attachments, so users see no difference.

**Storage:** S3/R2 downloads stream to the browser instead of being buffered in memory. `.env.example`
documents R2.

## Phase 2: services off the app box

* **`livekit-server/`**: a standalone repo for Coolify. livekit-server v1.13.11, host networking,
  config inline in the compose file from env vars (no secrets in git), several apps' keys in
  one `LIVEKIT_KEYS`, TURN/UDP on by default, optional TURN/TLS through Traefik SNI, optional Redis
  for multi-node, health check, key generator and `scripts/check.sh` (health + key/secret check
  against `/rtc/validate`). Config validated with the real v1.13.11 binary.
* **STT**: the sidecar is removed from the default `docker-compose.yml` (now
  `stt-sidecar/docker-compose.yml`, for a separate box). `.env.example` documents Groq, OpenAI,
  RunPod and sidecar options.
* **Health**: `/health` is liveness only (no DB call, so a slow database never makes Docker kill
  the app); `/ready` and `/api/health` check the database and return 503 when it is down. The
  Dockerfile `HEALTHCHECK` uses `/health`.
* **Correction to the old LiveKit doc**: its TURN/TLS recipe (Traefik :5349 → LiveKit :5350 on the
  signalling name) can't work, because LiveKit advertises `turns:<turn domain>:443`. The new
  README uses a separate TURN name routed by SNI on 443.

## Phase 3: feature folders for the team

Behaviour is unchanged; the code is moved, not rewritten.

* `src/features/<id>/` holds each feature: `ws.js` (WebSocket plugin), `routes.js` (JSON API),
  `http.js` (raw HTTP), `data.js` (queries), `migrations/`, `client/ws.js` (browser message
  handlers), `client/*.css`. Discovered automatically (`src/core/features.js`); `FEATURE_<NAME>=false`
  still turns a WebSocket plugin off.
* `src/http/routes.js` (1,550 lines) → a ~90-line pipeline + `src/core/auth-routes.js`,
  `src/core/room-routes.js` and feature `http.js` files. `src/http/venue.js` (730 lines) →
  `src/core/router.js` + 15 feature `routes.js` files (kept as a 15-line shim). Duplicate,
  unreachable `/api/venues/admins|audit` handlers were dropped (the live ones are in
  `features/venues/routes.js`).
* `src/venue/data.js` (806 lines) → 13 feature `data.js` files; `src/venue/data.js` is now a facade
  exporting exactly the same 91 functions.
* `src/plugins/*` → `src/features/<id>/ws.js`; the old `venue.js` mega-plugin split into stage,
  polls, qa, comments, scripture, captions and wbShare. Load order is identical (`order` numbers).
* Browser: `public/js/room/wsHandlers.js` keeps only core room messages; 70 message types moved
  to 19 feature `client/ws.js` files via `public/js/room/registry.js`. The server generates
  `/features/client.js` and `/features/features.css`. A duplicate, unreachable `scripture-clear`
  case was removed.
* CSS: the feature-specific tail of `room.css` (content slides, scripture hits) moved to feature
  CSS, loaded right after `room.css`, so the cascade order is unchanged. `app.css` was **not**
  split (its later override sections depend on order; see `docs/ARCHITECTURE.md`).
* Migrations: core in `migrations/`, per feature in `src/features/<id>/migrations/`, all sorted
  together by file name. New ones use UTC timestamps (`npm run migration:new -- name [--feature id]`).
  Existing `001_`–`013_` files and the `schema_migrations` records are unchanged.
* Team files: `CONTRIBUTING.md`, `.github/CODEOWNERS`, `.github/workflows/ci.yml`,
  `src/features/_template/`, `docs/ARCHITECTURE.md`.

**How "unchanged" was checked**
* Full test suite after every step (now 38 tests, including restart, phase-1, structure and an
  end-to-end smoke test).
* HTTP parity: 230 requests (every route, anonymous and signed-in) against the code before and
  after the routes split, each on a fresh database; status codes and response shapes were
  identical.
* API route order: 156 sample paths resolve to the same handler as before.
* Browser handlers: the old `wsHandlers.js` and the new registry were run side by side in Node
  on 86 message types × 48 room states × 2 message shapes (8,256 cases); the resulting room state,
  toasts, sounds and method calls were identical.

---

## Known limitations and risks

* **One app replica.** Rooms live in memory; do not scale the 1venue app to 2+ replicas yet.
* **Crashes still end meetings.** An OOM kill or `SIGKILL` writes no snapshot.
* **Rolling-deploy overlap.** For a few seconds old and new containers both run. A WebSocket
  message sent to the old one in that window can be lost (e.g. a chat line sent right as the
  deploy happens).
* **Left-participant pruning.** Someone who left more than 10 minutes ago is treated as new when
  they come back: room lock and waiting room apply to them like anyone new, and per-person state
  such as a raised hand is gone. Hosts and co-hosts are never pruned.
* **Smaller whiteboard caps** (see Phase 1). Raise `WB_MAX_STROKES` / `WB_MAX_POINTS` if heavy
  boards get trimmed.
* **Heartbeat** is now covered by a test (see the follow-up below). It can still be turned off
  with `WS_HEARTBEAT_MS=0` if unexpected disconnects show up.
* **TURN/TLS** and Coolify's handling of a domain on a host-network service were checked against
  the docs and the real binary's config parser, not on a live server.
* **Docker image** was not built here (no Docker on the build machine); the Dockerfile change is
  small (heap variable, health check).
* **Browser cache.** The service worker version was bumped so clients pick up the new room
  modules; a user with a very old open tab may need a reload.


---

## Follow-up (13 Nov 2026): polls N+1, monitoring, read-out (text-to-speech)

Commits on top of Phase 3, one per step. Tests: 49 passing (`npm test`).

### Polls: fewer database queries
* `listPolls` used 1 query plus 4 per poll (up to 121 for 30 polls), and `pollResults` used 5.
  Both now use **2 queries**: the poll rows, plus one grouped query for counts, voters and "mine".
* The output is the same. `test/polls.test.js` runs the old code (copied verbatim) and the new
  code on the same data and compares the results. The only difference: `mine` is now sorted.
  The old order was random, and the client only checks membership.

### Monitoring
* `GET /metrics` returns Prometheus text with these metrics:
  * rss, heap used, heap total
  * live rooms, connected participants, open sockets
  * `venue_ws_dead_sockets_terminated_total` (sockets the heartbeat killed)
  * uptime
* It needs `Authorization: Bearer $METRICS_TOKEN`. It returns **404 while `METRICS_TOKEN` is
  unset** and 401 for a wrong token.
* Once a minute the app logs one line:
  `[metrics] rss=..MB heap=used/totalMB rooms= participants= sockets= dead_sockets_total= uptime=..s`.
  Turn it off with `METRICS_LOG=false`. Change the interval with `METRICS_LOG_INTERVAL_MS`.
* Code: `src/core/metrics.js`, wired into `src/ws/hub.js`, `src/index.js` and `src/http/routes.js`.
  Tests in `test/metrics.test.js` cover the heartbeat really killing a dead socket.

### Read-out (text-to-speech) with Replicate `google/gemini-3.8-flash-tts`
The full guide is **docs/TTS.md** (setup, pricing as shown on the page, how languages are
decided, cost tips).
* **Model checked on Replicate (13 Nov 2026):**
  * It exists and is an official Google model.
  * Inputs: `text`, `voice` (30 voices, default `Kore`), `second_voice`, `style`, and
    `output_format` (`wav` or `mp3`).
  * **There is no language input.** The model detects the language from the text.
* **Languages (from Google's list linked on that page):**
  * **Igbo, Hausa and Arabic are supported.**
  * **Yorùbá is not supported**, and neither is Nigerian Pidgin.
* **Server** (`src/features/tts/`):
  * `POST /api/tts` is a proxy. The token stays on the server.
  * Only signed-in users and room participants can use it.
  * Languages are checked against an allowlist (Google's list, or `TTS_LANGUAGES`).
  * Text is limited to `TTS_MAX_CHARS`. Model directions (`<tags>`, `|pipes|`, `/IPA/`) are
    removed so content is read, not performed.
  * Limits: a per-person rate limit (`TTS_RATE_PER_MIN`, existing limiter), a whole-server daily
    character cap, and two people asking for the same text at once pay only once.
  * Audio is cached in storage (R2 or disk) by a hash of model + voice + format + language + text.
    Cache hits are free and not rate-limited. The cache is the `tts_cache` table (new migration).
  * `GET /api/tts/config` tells the browser what is on.
* **Browser:**
  * The 🔊 icon starts hidden. It only appears when:
    * the content's language is known (from metadata, or from a clear non-Latin script such as
      Arabic), **and**
    * either the server supports that language or the device has a voice for exactly that language.
  * Otherwise there is no icon, and never an English voice reading another language.
  * Latin-script text (Igbo, Hausa, Yorùbá, English) is never guessed; it needs metadata.
  * Room scripture now passes its translation, so English Qur'an translations are read in English.
    (They used to be treated as Arabic.)
  * The service worker version was bumped (v13) so browsers load the new files.
* Tests (`test/tts.test.js`) use a fake Replicate server: token never exposed, 401, unsupported
  language, size limit, request body and headers, polling, cache, rate limit, room credential,
  503 without a token, and the browser detection and gating rules. A headless-Chrome check on
  the Bible reader confirmed the icon appears for Igbo, Hausa, Arabic and English, is absent
  for Yorùbá, and that Listen/Stop works.

### Manual steps
1. Replicate: create an account, add billing (and a spend limit if offered), and create a token
   at <https://replicate.com/account/api-tokens>.
2. In Coolify, add `REPLICATE_API_TOKEN=r8_...` (a secret; never put it in git). Optional
   settings are in `.env.example` → *Text-to-speech*.
3. Monitoring: in Coolify, add `METRICS_TOKEN=<long random string>` (`openssl rand -hex 32`).
   Scrape it with Prometheus:
   ```yaml
   - job_name: 1venue
     scheme: https
     metrics_path: /metrics
     authorization: { type: Bearer, credentials: <METRICS_TOKEN> }
     static_configs: [{ targets: ['1venue.live'] }]
   ```
   Or check it by hand: `curl -H "Authorization: Bearer $METRICS_TOKEN" https://<domain>/metrics`.
4. Set `language` on events (e.g. `ig`, `ha`, `ar`) when creating them, so future read-out on
   events picks the right language.
5. Yorùbá: there is no read-out until a model supports it. To try anyway at your own risk, set
   `TTS_LANGUAGES=en,ig,ha,ar,yo` after listening to the quality yourself.

### Risks
* The text being read is sent to Replicate and Google, and every clip carries a SynthID watermark.
* Spend is bounded by caching, the per-person limit and the daily cap. Still set a spend limit
  on Replicate.
* The model is new, so its inputs or language list could change. Re-check the model page if
  read-out starts failing, and pin a version with `TTS_REPLICATE_MODEL=owner/name:version`.
* If you wipe the storage bucket but keep the database, run `DELETE FROM tts_cache;`.

---

## Own accounts, email, Google, new domain (13 Nov 2026)

1venue has its own accounts, sends its own email, offers "Continue with Google", and every
address comes from env (`PUBLIC_URL` and friends),
so it can run on 1venue.live or any other domain. Full guide: `docs/AUTH.md`; DNS/Cloudflare:
`docs/DEPLOY-1venue.live.md`.

**Migration note (the only place the previous setup is named):** 1venue previously ran at
`venue.collab.name.ng`, signed in through Collab Accounts (`accounts.collab.name.ng`) with shared
cookies on `.collab.name.ng`, and used LiveKit at `1v.collab.name.ng`. This release removes all of
it: the `ACCOUNTS_*` and `COOKIE_DOMAIN` settings, the shared `access_token`/`refresh_token`
cookies, the `/auth/me` relay and Set-Cookie forwarding, `ACCOUNTS_JWT_SECRET` checks, the
login/logout redirects, the "Use Collab Accounts" wording, and the `isInternalUsername` /
`publicUsername` display hacks. `users.accounts_id` stays, unused and nullable. Users created
through Collab Accounts are the "imported users" below. Keep the old app domain pointing at
1venue (with `CANONICAL_HOST=1venue.live`) for a while so old links and QR codes redirect.

### What changed
* **Local accounts** (`src/lib/auth.js`, `src/features/auth/`): sign up, sign in, sign out,
  sign out everywhere, per-device sign-out; 15-minute access JWT plus a rotating refresh token
  stored hashed in `auth_sessions` (reuse detection); cookies `__Host-1v_at` / `__Host-1v_rt`,
  `HttpOnly; Secure; SameSite=Lax`, host-only; bcrypt with `BCRYPT_COST`; rate limits; email
  verification (default: app usable with a banner; `AUTH_REQUIRE_VERIFIED_EMAIL=true` to
  require it); forgot/reset with single-use expiring tokens (reset signs out every device);
  change password (signs out other devices); change email with re-verification and a notice to
  the old address; `ALLOW_LOCAL_SIGNUP` kept; generic answers for sign-in, forgot and change-email.
* **Mail** (`src/features/mail/`): any SMTP server via nodemailer (`SMTP_HOST`, `SMTP_PORT`,
  `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASS`, `MAIL_FROM`, `MAIL_REPLY_TO`); branded HTML + text
  templates (confirm email, reset, set password, welcome, already-have-an-account, email
  changed); links printed to the log outside production when SMTP is not set; SMTP checked at boot.
* **Continue with Google** (`src/features/auth/google.js`, `http.js`): OIDC code flow with PKCE
  (S256), state and nonce in a signed short-lived cookie; ID token verified against Google's
  JWKS (signature, issuer, audience, expiry, nonce, `email_verified`); endpoints from Google's
  discovery document; links by verified email, else creates a user (`GOOGLE_ALLOW_SIGNUP`);
  new `oauth_identities` table; button hidden when not configured.
* **Imported users (no password):** migration `20261113230000_local_accounts` clears their never-used
  placeholder passwords and flags them; any sign-in attempt or "Forgot password" emails a
  set-password link; Google with the same verified email links automatically. Migration
  `20261113230100_clean_collab_usernames` turns `accounts:…`, `acc_…` and `u1a2b3c4_…`
  usernames into readable ones once (collisions get `_2`, `_3`, …).
* **Frontend:** new `/login` (sign in / sign up / forgot), `/reset-password` and `/verify-email`
  pages with the Google button; a "please confirm your email" banner; Settings → Account
  (email status, resend, change email, change/set password, Google status, devices, sign out
  everywhere). Service worker v14.
* **Domain:** `CANONICAL_HOST` middleware (301 to the canonical host, off when unset, health and
  metrics paths exempt). CORS defaults to `PUBLIC_URL` only. docker-compose no longer has a
  default domain (`PUBLIC_URL` is required). Examples use `1venue.live`, `wss://rtc.1venue.live`,
  `turn.1venue.live` and `https://files.1venue.live`; the livekit-server repo uses
  `LIVEKIT_DOMAIN=rtc.1venue.live` and `TURN_DOMAIN=turn.1venue.live`.
* **Docs:** new `docs/AUTH.md` and `docs/DEPLOY-1venue.live.md`; README, ARCHITECTURE,
  BLUEPRINT, FEATURE_INVENTORY (renamed), livekit-coolify, `.env.example`, package description and
  CODEOWNERS example updated. LICENSE (MIT, Oluebube Ogbonnaya) was not changed.
* **Tests:** 65 passing (`test/mail.test.js`, `test/auth.test.js`, `test/google.test.js` with a
  mocked Google, plus the existing suites). A headless-Chrome run covered sign-up, the banner,
  Settings → Account, confirming by email link, change password, forgot/reset, and sign-in
  errors, with no browser errors.

### Risks
* **Everyone has to sign in again** after this deploy: the old shared cookies are no longer
  read, and the new cookies are host-only with new names.
* **Imported users have no password.** They need the set-password email (sent when they
  try to sign in or use Forgot password) or Google. So **SMTP must work in production**, or
  they can only get in with Google. Users stored with a placeholder `@accounts.local` email
  cannot receive mail at all.
* With the default `AUTH_REQUIRE_VERIFIED_EMAIL=false`, sign-up answers differently when an email
  is already registered (it says "check your email" instead of signing in), which tells someone
  that the address has an account. Sign-in, forgot password and change email never do. Set
  `AUTH_REQUIRE_VERIFIED_EMAIL=true` to close this too, at the cost of making people confirm before
  using the app.
* Rate limits are in memory per process. Fine for the single app container; if you ever run
  several replicas, move them to Redis or Postgres.
* Rotating `JWT_SECRET` does **not** sign people out (refresh tokens live in the database). To
  force everyone out, run `UPDATE auth_sessions SET revoked_at = NOW() WHERE revoked_at IS NULL;`.
* Google sign-in only works for everyone once the OAuth app is **published**; in *Testing*,
  only listed test users can use it.
* Emails from a new domain often land in spam until SPF, DKIM and DMARC are set.

### Manual steps
1. **SMTP:** pick a provider (examples in `docs/AUTH.md`: Zoho, Gmail app password, Brevo,
   Mailgun), verify `1venue.live` with it (SPF/DKIM/DMARC in Cloudflare), and set `SMTP_HOST`,
   `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS` (secret), `MAIL_FROM` in Coolify. Check the boot log for
   `[mail] SMTP ready`.
2. **Google:** create the OAuth client (`docs/AUTH.md` → *Set up Continue with Google*) with
   redirect `https://1venue.live/auth/google/callback`, publish the app, and set
   `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` (secret) in Coolify.
3. **Coolify env:** set `PUBLIC_URL=https://1venue.live`, clear `CORS_ORIGINS` (or set it to
   `https://1venue.live`), optionally `CANONICAL_HOST=1venue.live`; **delete** `ACCOUNTS_URL`,
   `ACCOUNTS_LOGIN_URL`, `ACCOUNTS_ACCESS_COOKIE`, `ACCOUNTS_REFRESH_COOKIE`,
   `ACCOUNTS_JWT_SECRET`, `COOKIE_DOMAIN` and `JWT_TTL` (no longer read). Keep `JWT_SECRET`.
4. **DNS / Cloudflare / R2 / LiveKit names:** follow `docs/DEPLOY-1venue.live.md` (apex + www
   proxied, Full (strict), www → apex, `rtc` and `turn` grey cloud, `files` as the R2 custom
   domain). Update `LIVEKIT_URL=wss://rtc.1venue.live` and `S3_PUBLIC_BASE_URL=https://files.1venue.live`,
   and redeploy livekit-server with `LIVEKIT_DOMAIN=rtc.1venue.live`.
5. **Coolify domains:** add `https://1venue.live` (and `https://www.1venue.live` if you use
   `CANONICAL_HOST` instead of a Cloudflare redirect). Keep the old domain attached for a while
   so old links redirect.
6. **After deploy:** sign up with a real address, confirm the email arrives, try Forgot
   password and Continue with Google, and sign in with an imported account to see the
   set-password email arrive.
7. **Tell users** (in-app, WhatsApp, email): "1venue now has its own sign-in. Use Continue with
   Google, or tap Forgot password to set a password for your email."

### Orphaned files (compared with the original upload, commit `b7c436e`)
Files from the original repo that no longer exist at their old path:

| Old path | Now |
|---|---|
| `src/plugins/index.js` | deleted; replaced by feature discovery in `src/core/features.js` |
| `src/plugins/venue.js` | deleted; its routes moved into `src/features/*/routes.js` / `http.js` |
| `src/plugins/registry.js` | moved to `src/core/plugin-registry.js` |
| `src/plugins/{activity,breakout,chat,content,deviceIcons,groupChat,moderation,mute,privateChat,reactions,recording,screenTimeline,sounds,whiteboard}.js` | moved to `src/features/<name>/ws.js` |

If you unzip this over an old checkout instead of starting clean, delete the whole
`src/plugins/` folder: nothing loads it any more. This release (accounts/domain) deleted no
files. Still present but outdated: `docs/livekit/` (old in-repo LiveKit resource, kept one release
as a fallback; delete after the livekit-server move) and `screenshots/` (taken before the new
sign-in screens; not used by the app). A scan found no other unreferenced code files.

## Privacy and terms pages (14 Nov 2026)

Public, no-login pages at `https://1venue.live/privacy` and `https://1venue.live/terms` (also
`/privacy.html` and `/terms.html`) so Google OAuth publishing can be completed, and so anyone
can read how 1venue uses data and the terms of the service. They are standalone HTML (no
JavaScript required), use 1venue branding, and are linked from the sign-in / sign-up screens
and from Settings → About. Contact: `legal@1venue.live`.

The operator is named as **1venue**. If a registered legal entity exists, fill in its legal
name (and a postal address, if required) on both pages.

For Google Auth Platform → Branding, use:

* Home page: `https://1venue.live`
* Privacy policy: `https://1venue.live/privacy`
* Terms of service: `https://1venue.live/terms`
* Authorised domain: `1venue.live`

## Google 404 fix, username + phone on sign-up (14 Nov 2026)

**Continue with Google 404.** The server was already correct: `GET /auth/google/start` 302s to
Google with PKCE. The 404 (“This page drifted off the venue.”) came from the client: the SPA
click interceptor treated the button as an in-app route, and an installed service worker could
also intercept the navigation. `/auth/*` is now excluded from the click interceptor (the button
does a full-page load) and is network-only in the service worker. The SW version is
`v16-2026-11-14`. No Coolify env change is needed; redeploy so browsers pick up the new client
and service worker. (`curl -sI` on that path is misleading: the handler is GET-only, so HEAD
falls through to the SPA shell.)

**Sign-up** now requires a username and a phone number (Google accounts get a unique username
from the Google name or email, and can add or change both in Settings → Account):

* Username: 3–30 characters, lowercase letters, digits, underscore or period; cannot start or
  end with a period; reserved names (admin, support, login, signup, 1venue, and route names)
  are blocked. Live availability is checked at `GET /api/auth/username-available?u=`. A unique
  index on `LOWER(username)` makes races safe (migration `20261114080000_username_phone.sql`).
* Phone: stored in E.164, validated with libphonenumber-js, country selector defaults to
  Nigeria (+234). Not unique, not verified by SMS (`phone_verified` stays false). Not shared
  and not used for marketing. The privacy policy mentions both fields.

---

## Premium sign-in, demo data, read-out fix, Qur'an bar, public profiles (14 Nov 2026)

**Set in Coolify, then redeploy** (the new migration runs on start):
- `ADMIN_EMAILS=<your email>` — opens /admin (demo data + read-out check). The email must be confirmed.
- `TTS_LANGUAGES=ig,ha,ar` — cloud voice only where devices have no voice. Keep `REPLICATE_API_TOKEN`.

What changed:
- **Log in is an overlay** over the blurred page ("Log in or sign up", Google, OR, email/username →
  password, forgot password → "Check your inbox" with Resend). `/login` links still work. **Sign up**
  stays one page with floating-label fields; the helper texts are gone. Reset/verify pages match.
- **Demo data** — 10 complete accounts (password `@1venued`) with events, posts, comments, venues,
  materials, whiteboards, DMs and past sessions; load/remove from /admin or `npm run seed` /
  `npm run seed:remove`. See `docs/SEED.md`.
- **Read-out (TTS)** — device voice first, cloud only otherwise; icon shown to signed-out readers
  (tap → log in); faster first audio; iOS playback unlock; clearer errors. Diagnosis in `docs/TTS.md` §7.
- **Qur'an in the / bar** — "quran" or "q" lists all 114 surahs with Arabic names; "q 18",
  "kahf 10", "2:255", "الكهف", "q cave" jump straight to the surah/ayah.
- **Public profiles at `/u/<username>`** — case-insensitive; old `/u/<id>` and handle links 301 to
  the username; real 404 page for unknown users; share previews (og tags). Profile links app-wide
  use the username.
- Service worker v17.

## Materials uploads fix, Instant meeting overlay, composer mic toggle (Nov 15)

**Root cause of "materials uploads don't work":** with R2 (`STORAGE_DRIVER=s3`) and `S3_PUBLIC_BASE_URL`
set, `/api/files` returns `https://files.1venue.live/<key>`. Materials (`POST /api/materials`) and room
presenting (`content-start` over the socket) only accepted `/files/…` URLs, so every deck/PDF/image was
rejected *after* it had already reached the bucket. The 400 was never logged (only 5xx were) and the room
dropped the share silently while the client still toasted "Presenting to everyone".

- `src/lib/file-url.js`: one validator for stored-file URLs (`/files/…` or the S3 public base only).
- Materials, room slides/images and live deck edits use it; a rejected share now tells the presenter why.
- Decks no longer trip the 12/min upload limit: signed-in `purpose=content` uploads use the content limits.
- Runtime logs: `[upload] received/ok/failed`, `[storage] put ok/put failed (R2 status + error code)`,
  `[materials] create received/created/create failed (reason)`, `[pptx] …`, `[content] presenting/start rejected`.
- Client: clear upload errors (network, HTTP status, too big), event-materials attach failure is toasted.
- **Instant meeting** is an overlay over the current page (same blur and pill inputs as log in); hero,
  dashboard, command bar and old `/create?instant=1` links all open it.
- **Feed composer mic** is tap-to-talk: never listens on focus; tap again, typing, leaving the box,
  posting, ~12 s of silence or leaving the page stops it; it never restarts itself.
- Service worker v28, `app.css?v=19`.

## PDF / PPTX materials with spaces in the file name (Nov 15, follow-up)

**Root cause:** storage keys kept the original file name, so R2 URLs looked like
`https://files.1venue.live/2026/11/<id>-CV - Web Developer - Chinedu Okonkwo-p1.jpg` (raw spaces). The
stored-file validator added in the previous fix refused whitespace, so saving the material (and presenting the
pages in a meeting) was rejected with 400 even though every page reached R2. Single images worked only when
their name had no spaces. PPTX went through the same save step after conversion and failed the same way.

- Storage keys are slugs now (`…-CV-Web-Developer-Chinedu-Okonkwo-p1.jpg`); public URLs are percent-encoded.
- `src/lib/file-url.js` accepts raw or encoded URLs (old keys with spaces still save) and returns one canonical
  encoded form; traversal, encoded slashes, markup and control characters are still refused.
- File type detection reads the first bytes when the phone gives no type / extension (PDF, PPTX, images);
  .ppt / Keynote get a clear "save as PPTX or PDF" message.
- `[pptx] received` is logged first on every attempt (before auth / limits), every failure logs why, and the
  server logs at boot whether LibreOffice + poppler are present (`[pptx] converter ready` / `converter MISSING`).
- Browser-side failures in Materials, presenting and event-material attach are posted to `/api/client-log` and
  logged as `[client] materials error {step, message, file, mime, size, …}`, with a 7 s toast in the browser.
- Service worker v29, `app.css?v=20`.
