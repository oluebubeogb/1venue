// Permanent venues: /venues (my venues) and /v/{slug} (a venue's door).
import { icon } from '../icons.js';
import { h, api, toast, toastErr, timeAgo, copy, promptDlg, sheet } from '../ui.js';
import { state, requireLogin, navigate } from '../app.js';
import { empty } from '../components.js';

const fmtCode = (c) => String(c || '').toLowerCase().replace(/[^a-z0-9]/g, '');
const vlink = (slug) => `${location.origin}/v/${slug}`;
let timer = null;

/** Pick a themed icon from the venue name so lists aren’t all the same door. */
function venueIcon(name) {
  const n = String(name || '').toLowerCase();
  if (/school|class|learn|study|academy|lesson/.test(n)) return 'graduation';
  if (/church|chapel|fellowship|sermon|worship|sunday|prayer|bible|gospel|choir|youth|pastor/.test(n)) return 'church';
  if (/music|band|choir|concert|song|worship team/.test(n)) return 'music';
  if (/team|staff|office|work|standup|sync/.test(n)) return 'users';
  if (/talk|show|podcast|radio|live/.test(n)) return 'radio';
  if (/seminar|workshop|training|course/.test(n)) return 'presentation';
  if (/book|library|read/.test(n)) return 'bookOpen';
  if (/heart|care|love|family|fathers|mothers/.test(n)) return 'heart';
  if (/star|premium|vip/.test(n)) return 'star';
  if (/globe|world|online|remote/.test(n)) return 'globe';
  if (/lock|private|secure/.test(n)) return 'lock';
  if (/meeting|room|hall/.test(n)) return 'users';
  return 'door';
}
const venueMark = (name, size = 20) => h('span', { class: 'venue-mark', 'data-group': 'media', html: icon(venueIcon(name), { size }) });

/* Custom venue links. Free → 5+ chars + "-venue"; Premium/Organisation → 5+, no suffix; a venue's slug3 add-on → 3+; slug2 → 2+. */
const PLAN_LABEL = { free: 'Free', premium: 'Premium', organisation: 'Organisation', slug3: '3-char add-on', slug2: '2-char add-on' };
const RANK = { free: 0, premium: 1, organisation: 1, slug3: 2, slug2: 3 };
const rightsKey = (plan, tier) => (!plan || plan === 'free' ? 'free' : tier === 'slug3' || tier === 'slug2' ? tier : plan);
const slugBase = (v) => String(v || '').toLowerCase().replace(/-venue$/, '').replace(/[^a-z0-9]/g, '').slice(0, 16);
function previewSlug(base, plan) {
  if (!base) return { slug: '', err: '' };
  const r = RANK[plan] || 0;
  if (r === 0) return base.length >= 5 ? { slug: `${base}-venue` } : { slug: `${base.padEnd(5, '•')}-venue`, err: 'At least 5 letters/numbers on Free' };
  if (base.length < 2) return { slug: base, err: 'Too short' };
  if (base.length === 4 && r < 2) return { slug: base, err: 'Clean links need at least 5 characters (4 needs the slug3 add-on)' };
  if (base.length === 2 && r < 3) return { slug: base, err: '2-character links need the slug2 add-on (Billing)' };
  if (base.length === 3 && r < 2) return { slug: base, err: '3-character links need the slug3 add-on (Billing)' };
  if (base.length < 2) return { slug: base, err: 'Too short' };
  return { slug: base };
}
const planNote = (plan) => h('div', { class: 'tiny muted' },
  h('span', { class: 'chip tiny' }, PLAN_LABEL[plan] || 'Free'));
/** Sheet with name (optional) + custom URL field and live preview. Resolves { name, customSlug } or null. */
function venueDlg({ title, plan, name = '', withName = true, slugRequired = false, ok = 'Save' }) {
  return new Promise((resolve) => {
    let done = false;
    const s = sheet({ title, icon: 'door', onClose: () => { if (!done) resolve(null); } });
    const nameIn = h('input', { class: 'input', placeholder: 'e.g. Sunday fellowship', maxlength: 60, value: name });
    const slugIn = h('input', { class: 'input', placeholder: (RANK[plan] || 0) ? 'yourname' : 'faith', maxlength: 16, autocapitalize: 'none', autocomplete: 'off', spellcheck: 'false' });
    const prev = h('div', { class: 'small muted' });
    const paint = () => {
      const base = slugBase(slugIn.value); if (slugIn.value !== base) slugIn.value = base;
      const p = previewSlug(base, plan);
      prev.replaceChildren(base ? h('span', null, `${location.host}/v/`, h('strong', null, p.slug), p.err ? h('span', { style: { color: 'var(--danger, #e11d48)', marginLeft: '8px' } }, p.err) : null)
        : h('span', null, slugRequired ? 'Type your custom link' : 'Leave blank for a random link like /v/ydtd89r'));
      return p;
    };
    slugIn.addEventListener('input', paint);
    const submit = () => {
      const base = slugBase(slugIn.value), p = paint();
      if ((base || slugRequired) && (p.err || !base)) return toast(p.err || 'Enter a custom link', { icon: 'info' });
      if (withName && nameIn.value.trim().length < 2) return toast('Name your venue', { icon: 'info' });
      done = true; resolve({ name: nameIn.value.trim(), customSlug: base || null }); s.close();
    };
    [nameIn, slugIn].forEach((i) => i.addEventListener('keydown', (e) => e.key === 'Enter' && submit()));
    s.body.append(
      withName ? h('div', { class: 'small muted', style: { marginBottom: '.3rem' } }, 'Venue name') : null, withName ? nameIn : null,
      h('div', { class: 'small muted', style: { margin: '.8rem 0 .3rem' } }, 'Custom URL (letters and numbers)'), slugIn,
      h('div', { style: { marginTop: '.4rem' } }, prev), h('div', { style: { marginTop: '.6rem' } }, planNote(plan)),
      h('div', { class: 'row', style: { justifyContent: 'flex-end', marginTop: '1rem' } }, h('button', { class: 'btn ghost', onclick: () => s.close() }, 'Cancel'), h('button', { class: 'btn primary', onclick: submit }, ok)));
    paint();
  });
}
const myPlan = () => (state.user && state.user.plan) || 'free';

export async function mount(view, params) {
  clearTimeout(timer);
  if (params.list) return list(view);
  return door(view, String(params.slug || '').toLowerCase());
}
export function unmount() { clearTimeout(timer); }

function open(v, activityName) {
  const name = (activityName && String(activityName).trim()) || v.name;
  sessionStorage.setItem('venue.intent', JSON.stringify({ create: true, venue: v.slug, name, waitingRoom: true, code: v.code }));
  navigate('/' + fmtCode(v.code));
}

async function list(view) {
  if (!state.user) { view.append(empty('door', 'Venues', 'Sign in to create permanent venue links.', h('button', { class: 'btn primary', onclick: () => requireLogin('Sign in to create a venue') }, 'Sign in'))); return; }
  const wrap = h('div', { class: 'page narrow col venues-page', style: { gap: '14px' } });
  view.append(wrap);
  const paint = async () => {
    const { venues } = await api('/api/venues').catch((e) => { toastErr(e); return { venues: [] }; });
    const create = h('button', { class: 'btn primary', html: icon('plus', { size: 16 }) + 'New venue', onclick: async () => {
      const r = await venueDlg({ title: 'New venue', plan: myPlan(), ok: 'Create' });
      if (!r) return;
      try { await api('/api/venues', { method: 'POST', body: r }); paint(); } catch (e) { toastErr(e); if (/Upgrade/.test(e.message || '')) navigate('/upgrade'); }
    } });
    wrap.replaceChildren(
      h('div', { class: 'venues-head' },
        h('h1', { html: `<span class="venue-head-ic">${icon('door', { size: 22 })}</span> Venues` }),
        create),
      venues.length ? h('div', { class: 'col', style: { gap: '8px' } }, ...venues.map((v) => h('div', { class: 'card pad row wrap venue-row', style: { gap: '10px' } },
        venueMark(v.name, 20),
        h('div', { class: 'grow' }, h('div', null, h('strong', null, v.name), v.live ? h('span', { class: 'chip tiny', style: { marginLeft: '6px' } }, '● Open') : null, v.archived ? h('a', { class: 'chip tiny', href: '/upgrade', 'data-link': '', style: { marginLeft: '6px' } }, 'Archived · upgrade to reopen') : null),
          h('div', { class: 'tiny muted' }, `/v/${v.slug} · ${v.meetings || 0} meetings${v.lastHeld ? ' · last ' + timeAgo(v.lastHeld) : ''}`)),
        h('button', { class: 'btn sm ghost', 'data-tip': 'Copy link', html: icon('link', { size: 15 }), onclick: () => copy(vlink(v.slug), 'Venue link copied') }),
        h('a', { class: 'btn sm', href: `/v/${v.slug}`, 'data-link': '' }, 'Manage'),
        h('button', { class: 'btn sm primary', onclick: () => {
          if (v.live) return navigate('/' + fmtCode(v.code));
          navigate(`/v/${v.slug}`); // open from venue page so activity name can be set
        } }, v.live ? 'Rejoin' : 'Open')))) :
        empty('door', 'No venues yet', 'Create one to get a short link like /v/ydtd89r that you can reuse forever.'));
  };
  paint();
}

async function door(view, slug) {
  let v;
  try { v = await api(`/api/venues/${encodeURIComponent(slug)}`); }
  catch (e) { view.append(empty('door', 'Venue not found', 'Check the link and try again.', h('a', { class: 'btn', href: '/', 'data-link': '' }, 'Home'))); return; }
  // Bare /{slug} only opens auto (7-char) or free *-venue links; premium custom venues live under /v/ only.
  if (!location.pathname.startsWith('/v/') && v.isCustom && !/-venue$/.test(v.slug)) { view.append(empty('door', 'Venue not found', 'Check the link and try again.', h('a', { class: 'btn', href: '/', 'data-link': '' }, 'Home'))); return; }
  if (location.pathname !== `/v/${v.slug}`) history.replaceState({}, '', `/v/${v.slug}`);
  document.title = `${v.name} · 1venue`;
  const wrap = h('div', { class: 'page narrow col venue-door', style: { gap: '14px' } });
  view.append(wrap);
  if (v.isOwner) return ownerView(wrap, v);
  const poll = async () => {
    try { v = await api(`/api/venues/${encodeURIComponent(slug)}`); } catch { /* keep waiting */ }
    if (v.live && (v.live.open || v.live.hostIn)) { toast('Entering ' + v.name + '…'); navigate('/' + fmtCode(v.code), { replace: true }); return; }
    timer = setTimeout(poll, 3000);
  };
  const adminsBox = h('div', { class: 'col', style: { gap: '.5rem' } });
  const auditBox = h('div', { class: 'col', style: { gap: '.4rem' } });
  const adminInput = h('input', { class: 'input', placeholder: 'usernames, comma separated', style: { flex: 1 } });
  const loadAdmins = async () => {
    try {
      const { admins } = await api('/api/venues/admins?slug=' + encodeURIComponent(v.slug));
      adminsBox.replaceChildren(
        h('div', { class: 'row gap-s' }, adminInput, h('button', { class: 'btn sm', onclick: async () => {
          const names = adminInput.value.trim();
          if (!names) return;
          try {
            const r = await api('/api/venues/admins', { method: 'POST', body: { slug: v.slug, usernames: names } });
            toast(r.added.length ? 'Added ' + r.added.length : 'No valid usernames');
            adminInput.value = '';
            loadAdmins();
          } catch (e) { toastErr(e); }
        } }, 'Add')),
        ...(admins.length ? admins.map(a => h('div', { class: 'row between', style: { padding: '.4rem 0', borderBottom: '1px solid var(--line)' } },
          h('a', { href: '/u/' + a.username, 'data-link': '' }, h('b', null, a.name), h('span', { class: 'tiny muted' }, ' @' + a.username)),
          h('button', { class: 'btn sm ghost', onclick: async () => {
            if (!confirm('Remove ' + a.name + '?')) return;
            await api('/api/venues/admins', { method: 'DELETE', body: { slug: v.slug, userId: a.id } });
            loadAdmins();
          } }, 'Remove')
        )) : [h('div', { class: 'tiny muted' }, 'No admins yet.')])
      );
    } catch (e) { adminsBox.replaceChildren(h('div', { class: 'tiny muted' }, e.message)); }
  };
  const loadAudit = async () => {
    try {
      const { audit } = await api('/api/venues/audit?slug=' + encodeURIComponent(v.slug));
      auditBox.replaceChildren(...(audit.length ? audit.map(a => h('div', { class: 'tiny', style: { padding: '.3rem 0', borderBottom: '1px solid var(--line)' } },
        h('b', null, a.actorName), ' ', a.action, a.detail ? ' · ' + a.detail : '', h('span', { class: 'muted' }, ' · ' + timeAgo(a.at))
      )) : [h('div', { class: 'tiny muted' }, 'No activity yet.')]));
    } catch (e) { auditBox.replaceChildren(h('div', { class: 'tiny muted' }, e.message)); }
  };
  loadAdmins();
  loadAudit();
  wrap.append(h('div', { class: 'waiting' },
    h('span', { class: 'ico-tile lg', 'data-group': 'media', html: icon('door', { size: 28 }) }),
    h('h2', null, v.name),
    h('p', { class: 'muted' }, 'This venue isn’t open yet — wait a little. You’ll go in to the waiting room as soon as the host arrives.'),
    h('div', { class: 'dots-loader' }, h('i'), h('i'), h('i')),
    h('a', { class: 'btn ghost', href: '/', 'data-link': '' }, 'Leave')));
  if (v.live && (v.live.open || v.live.hostIn)) navigate('/' + fmtCode(v.code), { replace: true }); else timer = setTimeout(poll, 3000);
}

async function ownerView(wrap, v) {
  // Activity name is what shows on the session (e.g. "Youth Day") — venue name stays the permanent place name
  const name = h('input', { class: 'input', placeholder: 'e.g. Youth Day, Palm Sunday, Choir rehearsal', maxlength: 80, value: '' });
  const hist = h('div', { class: 'col', style: { gap: '6px' } }, h('div', { class: 'tiny muted' }, 'Loading meetings…'));
  const adminsBox = h('div', { class: 'col', style: { gap: '.5rem' } });
  const auditBox = h('div', { class: 'col', style: { gap: '.4rem' } });
  const adminInput = h('input', { class: 'input', placeholder: '@username, comma separated', style: { flex: 1 } });
  const loadAdmins = async () => {
    try {
      const { admins } = await api('/api/venues/admins?slug=' + encodeURIComponent(v.slug));
      adminsBox.replaceChildren(
        h('div', { class: 'row gap-s' }, adminInput, h('button', { class: 'btn sm', onclick: async () => {
          const names = adminInput.value.trim();
          if (!names) return;
          try {
            const r = await api('/api/venues/admins', { method: 'POST', body: { slug: v.slug, usernames: names } });
            toast(r.added.length ? 'Added ' + r.added.length : 'No valid usernames');
            adminInput.value = '';
            loadAdmins();
          } catch (e) { toastErr(e); }
        } }, 'Add')),
        ...(admins.length ? admins.map(a => h('div', { class: 'row between', style: { padding: '.4rem 0', borderBottom: '1px solid var(--line)' } },
          h('a', { href: '/u/' + a.username, 'data-link': '' }, h('b', null, a.name), h('span', { class: 'tiny muted' }, ' @' + a.username)),
          h('button', { class: 'btn sm ghost', onclick: async () => {
            if (!confirm('Remove ' + a.name + '?')) return;
            await api('/api/venues/admins', { method: 'DELETE', body: { slug: v.slug, userId: a.id } });
            loadAdmins();
          } }, 'Remove')
        )) : [h('div', { class: 'tiny muted' }, 'No admins yet.')])
      );
    } catch (e) { adminsBox.replaceChildren(h('div', { class: 'tiny muted' }, e.message)); }
  };
  const loadAudit = async () => {
    try {
      const { audit } = await api('/api/venues/audit?slug=' + encodeURIComponent(v.slug));
      auditBox.replaceChildren(...(audit.length ? audit.map(a => h('div', { class: 'tiny', style: { padding: '.3rem 0', borderBottom: '1px solid var(--line)' } },
        h('b', null, a.actorName), ' ', a.action, a.detail ? ' · ' + a.detail : '', h('span', { class: 'muted' }, ' · ' + timeAgo(a.at))
      )) : [h('div', { class: 'tiny muted' }, 'No activity yet.')]));
    } catch (e) { auditBox.replaceChildren(h('div', { class: 'tiny muted' }, e.message)); }
  };
  loadAdmins();
  loadAudit();
  const sec = (band, ic, title, tip, body) => h('section', { class: `venue-band ${band}` },
    h('div', { class: 'band-inner' },
      h('div', { class: 'venue-sec-h', 'data-tip': tip || null },
        h('span', { class: 'venue-mark', html: icon(ic, { size: 18 }) }),
        h('h3', null, title)),
      body));
  // Paid-plan branding (Free venues render plain: the server sends brand = null).
  const brand = v.brand || null;
  if (brand && brand.accent) { wrap.style.setProperty('--accent', brand.accent); if (brand.accent2) wrap.style.setProperty('--accent-2', brand.accent2); }
  wrap.append(
    brand && brand.coverUrl ? h('div', { class: 'venue-cover', style: { borderRadius: '16px', overflow: 'hidden', aspectRatio: '4 / 1', background: `linear-gradient(135deg, ${brand.accent || 'var(--accent)'}, ${brand.accent2 || 'var(--accent-2)'})` } },
      h('img', { src: brand.coverUrl, alt: '', style: { width: '100%', height: '100%', objectFit: 'cover', display: 'block' } })) : null,
    h('div', { class: 'row between wrap', style: { gap: '10px' } },
      h('div', { class: 'row', style: { gap: '.6rem', alignItems: 'center' } },
        brand && brand.logoUrl ? h('img', { src: brand.logoUrl, alt: '', width: 40, height: 40, style: { borderRadius: '10px', objectFit: 'cover' } }) : venueMark(v.name, 26),
        h('h1', { style: { margin: 0 } }, v.name),
        v.verified ? h('span', { class: 'chip tiny verified-badge', title: 'Verified host', html: icon('check', { size: 12 }) + 'Verified' }) : null),
      h('div', { class: 'row', style: { gap: '6px' } },
        h('button', { class: 'btn sm ghost', html: icon('link', { size: 15 }) + 'Copy link', onclick: () => copy(vlink(v.slug), 'Venue link copied') }),
        h('button', { class: 'btn sm ghost', html: icon('pencil', { size: 15 }) + 'Rename', onclick: async () => {
          const n = await promptDlg('Rename venue', { value: v.name, ok: 'Save' });
          if (!n) return;
          try { await api(`/api/venues/${v.slug}`, { method: 'PATCH', body: { name: n } }); toast('Renamed'); navigate(`/v/${v.slug}`, { replace: true }); } catch (e) { toastErr(e); }
        } }),
        h('button', { class: 'btn sm ghost', html: icon('link', { size: 15 }) + 'Custom URL', onclick: async () => {
          const r = await venueDlg({ title: 'Custom venue URL', plan: rightsKey(v.plan || myPlan(), v.slugTier), withName: false, slugRequired: true, ok: 'Save link' });
          if (!r || !r.customSlug) return;
          try { const nv = await api(`/api/venues/${v.slug}`, { method: 'PATCH', body: { customSlug: r.customSlug } }); toast('Link updated'); navigate(`/v/${nv.slug}`, { replace: true }); } catch (e) { toastErr(e); }
        } }))),
    brand && brand.about ? h('div', { class: 'card pad small', style: { whiteSpace: 'pre-line' } }, brand.about) : null,
    v.canManage ? h('p', { class: 'tiny muted' }, h('a', { href: '/host?tab=branding', 'data-link': '' }, 'Branding, analytics and more host tools →')) : null,
    planNote(rightsKey(v.plan || myPlan(), v.slugTier)),
    v.live
      ? h('div', { class: 'card pad row wrap', style: { gap: '10px' } }, h('div', { class: 'grow' }, h('strong', null, 'Open now: '), v.live.meetingName || v.name), h('button', { class: 'btn primary', onclick: () => navigate('/' + fmtCode(v.code)) }, 'Rejoin'))
      : h('div', { class: 'card pad col', style: { gap: '10px' } },
          h('strong', null, 'Activity name'),
          h('div', { class: 'row wrap', style: { gap: '8px' } },
            name,
            h('button', { class: 'btn primary', html: icon('video', { size: 16 }) + 'Open venue', onclick: () => {
              const activity = name.value.trim();
              if (!activity) return toast('Enter an activity name', { icon: 'info' });
              open(v, activity);
            } }))),
    sec('band-a', 'history', 'Sessions held here', 'Past meetings opened from this venue', hist),
    sec('band-b', 'shield', 'Admins', 'Admins can open this venue and manage the room', adminsBox),
    sec('band-c', 'activity', 'Audit', 'Who opened the venue, added admins, and other changes', auditBox));
  try {
    const { meetings } = await api(`/api/venues/${v.slug}/meetings`);
    hist.replaceChildren(...(meetings.length ? meetings.map((m) => h(m.id ? 'a' : 'div', { class: 'card pad row', href: `/session/${m.id}`, 'data-link': '', style: { gap: '10px' } },
      h('div', { class: 'grow' }, h('div', null, m.name), h('div', { class: 'tiny muted' }, `${new Date(m.started_at).toLocaleString()} · up to ${m.max_participants} people${m.ended_at ? '' : ' · open'}`)))) : [h('div', { class: 'tiny muted' }, 'No meetings yet.')]));
  } catch (e) { hist.replaceChildren(h('div', { class: 'tiny muted' }, e.message)); }
}
