// 1venue SPA shell: session, persisted preferences/theme, router, global commands.
import { creditBadge, setCreditUser } from './credits.js';
import { icon, LOGO } from './icons.js';
import { h, $, api, toast, sheet, menu, avatar, initTooltips, debounce, closeTopSheet, toastErr, errText, profilePath } from './ui.js';
import { mountCommandBar, registerCommands, setBarContext, barVisible, focusBar, refreshBar } from './commands.js';
import { surahCommands, loadSurahs, looksLikeQuran } from './quran-cmd.js';
import { initPwa, promptInstall } from './pwa.js';

export const state = { config: null, user: null, session: null, prefs: null, route: null, inRoom: false };
const LS_PREFS = 'venue.prefs';
const DEFAULT_PREFS = { theme: 'system', accent: '#2563eb', accent2: null, fontScale: 1, reduceMotion: false, bibleTranslation: 'eng_kjv', captionLang: null, extra: {} };
export const ACCENTS = [
  ['Ocean', '#2563eb', '#7c3aed'], ['Violet', '#7c3aed', '#db2777'], ['Rose', '#e11d48', '#f59e0b'], ['Sunset', '#ea580c', '#e11d48'],
  ['Gold', '#b7791f', '#ea580c'], ['Emerald', '#059669', '#0891b2'], ['Teal', '#0d9488', '#2563eb'], ['Graphite', '#334155', '#2563eb'],
];
export const FONT_SIZES = [['Small', 0.9], ['Default', 1], ['Large', 1.12], ['Extra large', 1.25], ['Huge', 1.4]];

/* ---------- preferences & theme ---------- */
const mql = matchMedia('(prefers-color-scheme: dark)');
export function applyPrefs(p = state.prefs) {
  const root = document.documentElement;
  const dark = p.theme === 'dark' || (p.theme === 'system' && mql.matches);
  root.dataset.theme = dark ? 'dark' : 'light';
  root.style.setProperty('--accent', p.accent || '#2563eb');
  const a2 = p.accent2 || (ACCENTS.find((x) => x[1] === p.accent) || [])[2] || '#7c3aed';
  root.style.setProperty('--accent-2', a2);
  root.style.setProperty('--font-scale', String(Math.min(1.5, Math.max(0.8, Number(p.fontScale) || 1))));
  root.classList.toggle('reduce-motion', !!p.reduceMotion);
  let meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = dark ? '#07090f' : '#f6f7fb';
}
mql.addEventListener('change', () => state.prefs && applyPrefs());
const pushPrefs = debounce(async () => { if (!state.user) return; try { await api('/api/prefs', { method: 'PUT', body: state.prefs }); } catch { /* offline: kept locally */ } }, 600);
export function setPrefs(patch, { silent = false } = {}) {
  state.prefs = { ...state.prefs, ...patch };
  localStorage.setItem(LS_PREFS, JSON.stringify(state.prefs));
  applyPrefs(); pushPrefs();
  if (!silent) window.dispatchEvent(new CustomEvent('prefs', { detail: state.prefs }));
}
function loadLocalPrefs() { try { return { ...DEFAULT_PREFS, ...JSON.parse(localStorage.getItem(LS_PREFS) || '{}') }; } catch { return { ...DEFAULT_PREFS }; } }

/* ---------- session ---------- */
export async function refreshSession() {
  try {
    const s = await api('/api/session?next=' + encodeURIComponent(location.pathname + location.search));
    state.session = s; state.user = s.user;
  } catch { state.session = { authenticated: false }; state.user = null; }
  if (state.user) {
    try { const p = await api('/api/prefs'); const local = loadLocalPrefs(); state.prefs = { ...DEFAULT_PREFS, ...p }; if (p.anonymous) state.prefs = local; applyPrefs(); localStorage.setItem(LS_PREFS, JSON.stringify(state.prefs)); } catch { /* keep local */ }
  }
  renderUserSlot();
  renderVerifyBanner();
  return state.user;
}
/** Local sign-in page. Optional path becomes `?next=`. */
export function loginUrl(nextPath) {
  const path = nextPath && String(nextPath).startsWith('/') ? nextPath : (location.pathname + location.search);
  return `/login?next=${encodeURIComponent(path)}`;
}
export function signupUrl(nextPath) {
  const path = nextPath && String(nextPath).startsWith('/') ? nextPath : (location.pathname + location.search);
  return `/signup?next=${encodeURIComponent(path)}`;
}
/** Instant meeting setup = an overlay over whatever page you are on (blurred underneath). */
export function openInstantOverlay(opts) {
  return import('./instant.js').then((m) => m.openInstant(opts)).catch(() => navigate('/create?instant=1'));
}
/** Log in = an overlay over the current (blurred) page; sign up = its own page. */
export function goLogin(nextPath, { signup = false, mode } = {}) {
  if (signup) return navigate(signupUrl(nextPath));
  const next = nextPath && String(nextPath).startsWith('/') ? nextPath : location.pathname + location.search;
  import('./pages/login.js').then((m) => m.openAuth({ next, mode })).catch(() => navigate(loginUrl(next)));
}
export function requireLogin() {
  if (state.user) return true;
  goLogin();
  return false;
}
export async function logout() {
  try { await api('/api/logout', { method: 'POST' }); } catch { /* ignore */ }
  state.user = null; state.session = { authenticated: false }; renderUserSlot();
  navigate('/');
}

/* ---------- "confirm your email" banner ---------- */
function renderVerifyBanner() {
  document.getElementById('verify-banner')?.remove();
  const pending = state.session?.pendingVerification;
  const u = state.user;
  if (state.inRoom || (!pending && (!u || u.emailVerified))) return;
  const email = pending ? pending.email : u.email;
  const send = h('button', { class: 'btn sm', type: 'button' }, 'Resend link');
  send.onclick = async () => {
    send.disabled = true;
    try { const r = await api('/api/auth/resend-verification', { method: 'POST' }); toast(r.message || 'Sent', { icon: 'mail' }); } catch (e) { toastErr(e); } finally { setTimeout(() => { send.disabled = false; }, 30000); }
  };
  const bar = h('div', { id: 'verify-banner', class: 'verify-banner', role: 'status' },
    h('span', { html: icon('mail', { size: 18 }) }),
    h('span', { class: 'grow' }, pending ? `Confirm ${email} to start using 1venue. Check your inbox.` : `Please confirm your email (${email}). We sent you a link.`),
    send,
    pending ? null : h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Dismiss', html: icon('x', { size: 16 }), onclick: () => bar.remove() }));
  $('#view')?.before(bar);
}

/* ---------- router ---------- */
const ROUTES = [
  [/^\/$/, () => import('./pages/home.js')],
  [/^\/discover\/?$/, () => import('./pages/discover.js')],
  [/^\/search\/?$/, () => import('./pages/discover.js'), { search: true }],
  [/^\/e\/([\w-]+)\/?$/, () => import('./pages/event.js'), 'slug'],
  [/^\/create\/?$/, () => import('./pages/create.js')],
  [/^\/materials\/?$/, () => import('./pages/materials.js')],
  [/^\/dashboard\/?$/, () => import('./pages/dashboard.js')],
  [/^\/a\/([a-f0-9]{32,})\/?$/, () => import('./pages/attendance.js'), 'token'],
  [/^\/feed\/?$/, () => import('./pages/feed.js')],
  [/^\/u\/([\w.-]+)\/?$/, () => import('./pages/profile.js'), 'id'],
  [/^\/me\/?$/, () => import('./pages/profile.js'), { me: true }],
  [/^\/wallet\/?$/, () => import('./pages/wallet.js')],
  [/^\/upgrade\/?$/, () => import('./pages/upgrade.js')],
  [/^\/billing\/?$/, () => import('./pages/billing.js')],
  [/^\/host\/?$/, () => import('./pages/host.js')],
  [/^\/replay\/(\d+)\/?$/, () => import('./pages/replay.js'), 'id'],
  [/^\/settings\/?$/, () => import('./pages/settings.js')],
  [/^\/books\/?$/, () => import('./pages/bible.js')],
  // Legacy /bible → /books (same page; Qur’an is a first-class peer, not an afterthought)
  [/^\/bible\/?$/, () => import('./pages/bible.js')],
  [/^\/sessions\/?$/, () => import('./pages/session.js'), { list: true }],
  [/^\/session\/(\d+)\/?$/, () => import('./pages/session.js'), 'id'],
  [/^\/whiteboard\/?$/, () => import('./pages/whiteboard.js')],
  [/^\/login\/?$/, () => import('./pages/login.js')],
  [/^\/admin\/?$/, () => import('./pages/admin.js')],
  [/^\/signup\/?$/, () => import('./pages/login.js'), { mode: 'signup' }],
  [/^\/forgot-password\/?$/, () => import('./pages/login.js'), { mode: 'forgot' }],
  [/^\/reset-password\/?$/, () => import('./pages/reset.js')],
  [/^\/verify-email\/?$/, () => import('./pages/verify.js')],
  [/^\/venues\/?$/, () => import('./pages/venue.js'), { list: true }],
  [/^\/v\/([A-Za-z0-9]{2,16}(?:-venue)?)\/?$/, () => import('./pages/venue.js'), 'slug'],
  [/^\/(?=[A-Za-z]*\d)(?=\d*[A-Za-z])([A-Za-z0-9]{7})\/?$/, () => import('./pages/venue.js'), 'slug'],
  [/^\/([A-Za-z0-9]{5,16}-venue)\/?$/, () => import('./pages/venue.js'), 'slug'],
  [/^\/new\/?$/, () => import('./room/room.js'), { code: null, instant: true }],
  // Meeting rooms: /y5yi87 (also /r/…, /j/…, and legacy /ABC-234 pastes)
  [/^\/(?:r\/|j\/)?([A-Za-z0-9]{3}-?[A-Za-z0-9]{3})\/?$/, () => import('./room/room.js'), 'code'],
];
// Pages with a "Promoted" sidebar (wide) / inline card (phones). Discover and Feed place their own inline card.
const RAILS = [[/^\/discover\/?$/, 'discover', false], [/^\/venues\/?$/, 'venues'], [/^\/(?:books|bible)\/?$/, 'books']];
let currentPage = null;
let routeSeq = 0;
export function navigate(to, { replace = false } = {}) {
  if (to === location.pathname + location.search && !replace) { route(); return; }
  history[replace ? 'replaceState' : 'pushState']({}, '', to);
  route();
}
async function route() {
  const path = location.pathname;
  closeTopSheet();
  for (const [re, load, extra] of ROUTES) {
    const m = path.match(re); if (!m) continue;
    const params = Object.fromEntries(new URLSearchParams(location.search));
    if (typeof extra === 'string') params[extra] = decodeURIComponent(m[1]); else if (extra) Object.assign(params, extra);
    try { currentPage && currentPage.unmount && currentPage.unmount(); } catch { /* ignore */ }
    currentPage = null;
    delete document.body.dataset.page;
    const seq = ++routeSeq;
    const view = $('#view'); view.replaceChildren(); view.className = 'main page-enter';
    void view.offsetWidth;
    try {
      const mod = await load();
      if (seq !== routeSeq) return;
      view.replaceChildren();
      state.route = { path, params, mod };
      const isRoom = !!mod.isRoom; setRoomMode(isRoom);
      highlightNav(path);
      const res = await mod.mount(view, params);
      if (seq !== routeSeq) { try { (res || mod).unmount?.(); } catch { /* ignore */ } return; }
      currentPage = res || mod;
      if (!isRoom) setBarContext(globalBarContext(mod.barPinned));
      const rail = RAILS.find(([re]) => re.test(path));
      if (rail && !params.search) import('./promo.js').then((m) => { if (seq === routeSeq) m.attachPromoRail(view, rail[1], { inline: rail[2] !== false }); }).catch(() => {});
    } catch (e) {
      if (seq !== routeSeq) return;
      view.replaceChildren();
      if (e?.status === 404) { view.append(h('div', { class: 'empty' }, frag404())); window.scrollTo(0, 0); return; }
      if (e?.status === 401) {
        const a = h('a', { class: 'btn primary', href: loginUrl(location.pathname), 'data-link': '', style: { margin: '1rem auto 0', width: 'fit-content' } }, 'Sign in');
        view.append(h('div', { class: 'empty' }, h('h2', null, 'Sign in to continue'), h('p', { class: 'muted' }, 'This page needs an account.'), a));
        return;
      }
      console.error(e);
      view.append(h('div', { class: 'empty' }, h('h2', null, 'Something went wrong'), h('p', { class: 'muted' }, errText(e) || 'Please try again.'), h('div', { class: 'row', style: { gap: '.5rem', justifyContent: 'center', marginTop: '1rem' } }, h('button', { class: 'btn', type: 'button', onclick: () => route() }, 'Try again'), h('a', { class: 'btn primary', href: '/' }, 'Go home'))));
    }
    window.scrollTo(0, 0);
    return;
  }
  ++routeSeq;
  setRoomMode(false);
  $('#view').innerHTML = '';
  $('#view').append(h('div', { class: 'empty' }, frag404()));
}
function frag404() { return h('div', null, h('h1', null, '404'), h('p', { class: 'muted' }, 'This page drifted off the venue.'), h('a', { class: 'btn primary', href: '/', style: { margin: '1rem auto 0', width: 'fit-content' } }, 'Back home')); }
export function setRoomMode(on) {
  state.inRoom = on;
  document.body.classList.toggle('in-room', on);
  $('.topbar').classList.toggle('hidden', on); $('.bottomnav').classList.toggle('hidden', on);
}

/* ---------- shell ---------- */
const NAV = [
  ['/', 'home', 'Home'], ['/discover', 'compass', 'Discover'], ['/feed', 'feed', 'Feed'], ['/dashboard', 'dashboard', 'Dashboard'],
];
function highlightNav(path) {
  document.querySelectorAll('[data-nav]').forEach((a) => {
    const p = a.getAttribute('data-nav');
    a.classList.toggle('on', p === '/' ? path === '/' : path.startsWith(p));
  });
  // Books is active for /books (and legacy /bible)
  document.querySelectorAll('[data-nav-books]').forEach((a) => {
    a.classList.toggle('on', path.startsWith('/books') || path.startsWith('/bible'));
  });
}
function openBooksPicker(anchor) {
  // Close any existing
  document.getElementById('books-picker')?.remove();
  const rect = anchor.getBoundingClientRect();
  const picker = h('div', {
    id: 'books-picker',
    class: 'books-picker',
    role: 'menu',
    'aria-label': 'Choose scripture',
  });
  const go = (corpus) => {
    picker.classList.add('out');
    setTimeout(() => picker.remove(), 180);
    navigate(corpus === 'quran' ? '/books?corpus=quran' : '/books?corpus=bible');
  };
  picker.append(
    h('button', { class: 'books-opt', type: 'button', role: 'menuitem', onclick: () => go('bible') },
      h('span', { class: 'books-opt-ic', html: icon('bookOpen', { size: 18 }) }),
      h('span', null, 'Bible')),
    h('button', { class: 'books-opt', type: 'button', role: 'menuitem', onclick: () => go('quran') },
      h('span', { class: 'books-opt-ic', html: icon('book', { size: 18 }) }),
      h('span', null, 'Qur’an')),
  );
  document.body.append(picker);
  // Position: prefer under the anchor, keep fully on-screen horizontally
  const pad = 8;
  const pw = picker.offsetWidth || 220;
  let left = rect.left + rect.width / 2 - pw / 2;
  left = Math.max(pad, Math.min(left, window.innerWidth - pw - pad));
  let top = rect.bottom + 8;
  if (top + picker.offsetHeight > window.innerHeight - pad) top = Math.max(pad, rect.top - picker.offsetHeight - 8);
  picker.style.left = `${left}px`;
  picker.style.top = `${top}px`;
  requestAnimationFrame(() => picker.classList.add('show'));
  const close = (e) => {
    if (e && picker.contains(e.target)) return;
    picker.classList.add('out');
    setTimeout(() => picker.remove(), 180);
    document.removeEventListener('pointerdown', close, true);
    document.removeEventListener('keydown', onKey, true);
  };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  setTimeout(() => {
    document.addEventListener('pointerdown', close, true);
    document.addEventListener('keydown', onKey, true);
  }, 0);
}
let creditControl;
function renderUserSlot() {
  const slot = $('#userslot'); if (!slot) return;
  creditControl?.unsubscribe(); creditControl=null;
  slot.innerHTML = '';
  setCreditUser(state.user?.id || null);
  if (state.user) {
    const b = h('button', { class: 'icon-btn', 'data-tip': state.user.displayName, 'aria-label': 'Account menu', style: { width: 'auto', padding: '0 2px' } }, avatar(state.user.displayName, state.user.avatarUrl, 'sm ring'));
    b.onclick = () => menu(b, [
      { label: state.user.displayName, icon: 'user', hint: '@' + state.user.username, run: () => navigate(profilePath(state.user)) },
      { label: 'Dashboard', icon: 'dashboard', run: () => navigate('/dashboard') },
      { label: 'Plan & billing', icon: 'crown', run: () => navigate('/billing') },
      { label: 'Host tools', icon: 'chart', run: () => navigate('/host') },
      { label: 'Credit wallet', icon: 'creditCard', run: () => navigate('/wallet') },
      { label: 'My sessions', icon: 'history', run: () => navigate('/sessions') },
      { label: 'My whiteboard', icon: 'board', group: 'content', run: () => navigate('/whiteboard') },
      { label: 'Settings', icon: 'settings', group: 'settings', run: () => navigate('/settings') },
      state.user.isAdmin ? { label: 'Admin', icon: 'shield', group: 'admin', run: () => navigate('/admin') } : null, '-',
      { label: 'Sign out', icon: 'logout', group: 'admin', run: logout },
    ]);
    creditControl=creditBadge();
    slot.append(creditControl.badge,b);
  } else {
    slot.append(h('a', { class: 'btn sm primary', href: loginUrl(location.pathname + location.search), 'data-link': '' }, frag(icon('login', { size: 16 })), 'Log in'));
  }
  const meTab = document.querySelector('.bottomnav [data-nav="/me"] span');
  if (meTab) meTab.textContent = state.user ? 'Me' : 'Log in';
}
const frag = (s) => document.createRange().createContextualFragment(s);
function buildShell() {
  const app = $('#app'); app.innerHTML = '';
  const themeBtn = h('button', { class: 'icon-btn', 'data-group': 'settings', 'data-tip': 'Toggle light / dark', 'aria-label': 'Toggle theme', onclick: toggleTheme, html: icon('moon') });
  const booksBtn = h('button', {
    class: 'topnav-books',
    type: 'button',
    'data-nav-books': '',
    'aria-haspopup': 'menu',
    'aria-label': 'Books — Bible and Qur’an',
    html: icon('bookOpen', { size: 18 }) + 'Books',
  });
  booksBtn.onclick = (e) => { e.preventDefault(); openBooksPicker(booksBtn); };
  const top = h('header', { class: 'topbar' },
    h('a', { class: 'brand', href: '/', 'data-link': '', html: LOGO(30) + '<span>1venue</span>' }),
    h('nav', { class: 'topnav', 'aria-label': 'Primary' },
      ...NAV.map(([p, ic, l]) => h('a', { href: p, 'data-link': '', 'data-nav': p, html: icon(ic, { size: 18 }) + l })),
      booksBtn),
    h('div', { class: 'grow' }),
    h('a', { class: 'btn sm primary top-desktop', href: '/create', 'data-link': '', html: icon('plus', { size: 16 }) + 'Create' }),
    h('div', { class: 'row', 'data-group': 'nav', style: { gap: '2px' } },
      h('a', { class: 'icon-btn', href: '/settings', 'data-link': '', 'data-group': 'settings', 'data-tip': 'Settings', 'aria-label': 'Settings', html: icon('settings') }),
      themeBtn, h('div', { id: 'userslot', class: 'row' })),
  );
  const bottom = h('nav', { class: 'bottomnav', 'aria-label': 'Primary' },
    h('a', { href: '/', 'data-link': '', 'data-nav': '/', html: icon('home', { size: 22 }) + '<span>Home</span>' }),
    h('a', { href: '/discover', 'data-link': '', 'data-nav': '/discover', html: icon('compass', { size: 22 }) + '<span>Discover</span>' }),
    h('a', { href: '/create', 'data-link': '', class: 'fab', 'aria-label': 'Create', html: `<span class="fabc">${icon('plus', { size: 26 })}</span>` }),
    h('a', { href: '/feed', 'data-link': '', 'data-nav': '/feed', html: icon('feed', { size: 22 }) + '<span>Feed</span>' }),
    h('a', { href: '/me', 'data-link': '', 'data-nav': '/me', html: icon('user', { size: 22 }) + '<span>Me</span>' }),
  );
  const main = h('main', { id: 'view', class: 'main' });
  app.append(top, main, bottom);
  mountCommandBar(document.body);
  const syncThemeIcon = () => { themeBtn.innerHTML = icon(document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon'); };
  window.addEventListener('prefs', syncThemeIcon); syncThemeIcon();
}
export function toggleTheme() {
  const dark = document.documentElement.dataset.theme === 'dark';
  setPrefs({ theme: dark ? 'light' : 'dark' });
  toast(dark ? 'Light mode' : 'Dark mode', { icon: dark ? 'sun' : 'moon', group: 'settings', ms: 1400 });
}
export function bumpFont(d) {
  const v = Math.round(Math.min(1.5, Math.max(0.8, (state.prefs.fontScale || 1) + d)) * 100) / 100;
  setPrefs({ fontScale: v }); toast(`Text size ${Math.round(v * 100)}%`, { icon: 'type', group: 'settings', ms: 1200 });
}

/* ---------- global commands (every page and setting) ---------- */
const BIBLE_REF = /^\s*([1-3]?\s?[a-z]+\.?)\s+(\d+)(?::(\d+)(?:-(\d+))?)?\s*$/i;
export const fmtCode = (c) => String(c || '').toLowerCase().replace(/[^a-z0-9]/g, '');
export const CODE_RE = /^\s*([a-z0-9]{3})[\s-]?([a-z0-9]{3})\s*$/i;
export const parseCode = (v) => { const m = String(v || '').match(CODE_RE); return m ? (m[1] + m[2]).toLowerCase() : null; };
export function globalBarContext(pinnedOverride) {
  return {
    placeholders: ['Search events, people, verses…', 'Try “go live”', 'Try “John 3:16”', 'Try “quran” for every surah', 'Try “Al-Kahf 10”', 'Try “dark mode”', 'Join with a code: y5yi87', 'Try “bigger text”', 'Try “sermons live now”', 'Try “my whiteboard”'],
    pinned: () => pinnedOverride ? pinnedOverride() : ['create', 'join', 'discover', 'live', 'feed', 'bible', 'quran', 'dashboard', 'materials', 'whiteboard', 'theme', 'settings'].map(cmdById),
    dynamic: (q) => {
      const out = [];
      const c = /\d/.test(q) ? parseCode(q) : null;
      if (c) out.push({ id: 'dyn-join', label: `Join ${c}`, icon: 'login', group: 'people', run: () => navigate(`/${c}`) });
      // Qur'an: "quran"/"q"/"surah …", Arabic, "2:255" or "Kahf 10" lead; a bare name ("kahf") is offered after Search.
      const surahs = surahCommands(q, loadSurahs(refreshBar), navigate);
      const quranFirst = surahs.length && (looksLikeQuran(q) || (surahs.length === 1 && /\d/.test(q)));
      const b = q.match(BIBLE_REF);
      if (b && b[1].length > 1 && !quranFirst) out.push({ id: 'dyn-bible', label: `Open ${q.trim()}`, icon: 'bookOpen', group: 'faith', run: () => navigate('/books?ref=' + encodeURIComponent(q.trim())) });
      if (quranFirst) out.push(...surahs);
      out.push({ id: 'dyn-search', label: `Search “${q.trim().slice(0, 24)}”`, short: 'Search all', icon: 'search', group: 'nav', tail: true, run: () => navigate('/search?q=' + encodeURIComponent(q.trim())) });
      if (!quranFirst) out.push(...surahs.slice(0, 6).map((c) => ({ ...c, tail: true })));
      return out;
    },
    fallback: (q) => navigate('/search?q=' + encodeURIComponent(q)),
  };
}
const CATS = [['talk_show', 'Talk shows', 'tv'], ['presentation', 'Presentations', 'presentation'], ['seminar', 'Seminars', 'graduation'], ['sermon', 'Sermons', 'church'], ['webinar', 'Webinars', 'globe'], ['workshop', 'Workshops', 'wrench'], ['meeting', 'Meetings', 'users'], ['concert', 'Concerts', 'music'], ['class', 'Classes', 'book']];
export { CATS };
let GLOBAL = [];
export const cmdById = (id) => GLOBAL.find((c) => c.id === id);
function registerGlobal() {
  const go = (p) => () => navigate(p);
  GLOBAL = [
    { id: 'create', label: 'Create event', short: 'Create', icon: 'plus', group: 'engage', keywords: ['go live', 'host', 'new meeting', 'schedule', 'start'], run: go('/create') },
    { id: 'instant', label: 'Start instant meeting', short: 'Instant', icon: 'zap', group: 'media', keywords: ['meet now', 'quick call', 'new room'], run: () => openInstantOverlay() },
    { id: 'venues', label: 'Venues — permanent links', short: 'Venue', icon: 'door', group: 'media', keywords: ['venue', 'permanent room', 'personal room', 'short link', '/v/'], run: go('/venues') },
    { id: 'join', label: 'Join with code', short: 'Join', icon: 'login', group: 'people', keywords: ['enter code', 'meeting code', 'room'], run: () => joinPrompt() },
    { id: 'discover', label: 'Discover events', short: 'Discover', icon: 'compass', group: 'nav', keywords: ['browse', 'explore'], run: go('/discover') },
    { id: 'live', label: 'Live now', icon: 'radio', group: 'engage', keywords: ['happening', 'streaming', 'on air'], run: go('/discover?status=live') },
    ...CATS.map(([k, l, ic]) => ({ id: 'cat-' + k, label: l, icon: ic, group: k === 'sermon' ? 'faith' : 'content', keywords: ['category', k.replace('_', ' ')], run: go('/discover?category=' + k) })),
    { id: 'home', label: 'Home', icon: 'home', group: 'nav', run: go('/') },
    { id: 'feed', label: 'Social feed', short: 'Feed', icon: 'feed', group: 'social', keywords: ['timeline', 'posts'], run: go('/feed') },
    { id: 'post', label: 'New post', icon: 'pen', group: 'social', keywords: ['write', 'share update', 'status'], run: go('/feed?compose=1') },
    { id: 'dashboard', label: 'Dashboard', icon: 'dashboard', group: 'nav', keywords: ['stats', 'analytics'], run: go('/dashboard') },
    { id: 'host', label: 'Host tools', short: 'Host', icon: 'chart', group: 'settings', keywords: ['analytics', 'branding', 'recurring', 'tickets', 'earnings', 'payout', 'promote', 'organisation', 'replays', 'export'], when: () => !!state.user, run: go('/host') },
    { id: 'billing', label: 'Plan & billing', short: 'Billing', icon: 'crown', group: 'settings', keywords: ['upgrade', 'premium', 'organisation', 'subscription', 'plan', 'pricing'], when: () => !!state.user, run: go('/billing') },
    { id: 'upgrade', label: 'Plans and pricing', icon: 'crown', group: 'settings', keywords: ['upgrade', 'premium', 'price'], when: () => true, run: go('/upgrade') },
    { id: 'wallet', label: 'Credit wallet', short: 'Credits', icon: 'creditCard', group: 'settings', keywords: ['credits', 'balance', 'payments', 'paystack', 'top up', 'buy credits'], when: () => !!state.user, run: go('/wallet') },
    { id: 'materials', label: 'Materials library', short: 'Materials', icon: 'folder', group: 'content', keywords: ['decks', 'slides', 'pdf', 'pptx', 'present', 'library', 'uploads'], when: () => !!state.user, run: go('/materials') },
    { id: 'profile', label: 'My profile', icon: 'user', group: 'people', keywords: ['me', 'account', 'timeline', 'public page'], run: () => navigate(state.user ? profilePath(state.user) : '/me') },
    { id: 'edit-profile', label: 'Edit profile', icon: 'pen', group: 'people', keywords: ['bio', 'avatar', 'name', 'handle'], run: go('/me?edit=1') },
    { id: 'people', label: 'Find people', icon: 'users', group: 'people', keywords: ['follow', 'friends', 'search users'], run: go('/search?tab=people') },
    { id: 'my-events', label: 'My events', icon: 'calendar', group: 'engage', keywords: ['hosting', 'scheduled', 'upcoming'], run: go('/dashboard#hosting') },
    { id: 'sessions', label: 'Past sessions & transcripts', short: 'Sessions', icon: 'history', group: 'content', keywords: ['history', 'transcripts', 'summaries', 'recordings'], run: go('/sessions') },
    { id: 'bible', label: 'Bible', icon: 'bookOpen', group: 'faith', keywords: ['scripture', 'read', 'verse', 'books'], run: go('/books?corpus=bible') },
    { id: 'quran', label: 'Qur’an', short: 'Qur’an', icon: 'book', group: 'faith', keywords: ['quran', 'koran', 'surah', 'surahs', 'ayah', 'islam', 'books', 'القرآن'], run: go('/books?corpus=quran') },
    { id: 'bible-tr', label: 'Bible translation', icon: 'languages', group: 'faith', keywords: ['kjv', 'web', 'yoruba', 'version'], run: go('/settings#bible') },
    { id: 'whiteboard', label: 'My whiteboards', short: 'Whiteboard', icon: 'board', group: 'content', keywords: ['draw', 'sketch', 'personal', 'saved boards'], when: () => !state.inRoom, run: go('/whiteboard') },
    { id: 'qr', label: 'Make a QR code', icon: 'qr', group: 'content', keywords: ['invite', 'poster'], run: () => import('./pages/event.js').then((m) => m.qrMaker()) },
    { id: 'settings', label: 'Settings', icon: 'settings', group: 'settings', run: go('/settings') },
    { id: 'theme', label: 'Toggle dark mode', short: 'Theme', icon: () => (document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon'), group: 'settings', keywords: ['light', 'dark', 'night'], run: toggleTheme },
    { id: 'theme-light', label: 'Light theme', icon: 'sun', group: 'settings', run: () => setPrefs({ theme: 'light' }) },
    { id: 'theme-dark', label: 'Dark theme', icon: 'moon', group: 'settings', run: () => setPrefs({ theme: 'dark' }) },
    { id: 'theme-system', label: 'Match system theme', icon: 'sliders', group: 'settings', keywords: ['auto', 'device'], run: () => setPrefs({ theme: 'system' }) },
    ...ACCENTS.map(([n, a, a2]) => ({ id: 'accent-' + n, label: `Accent: ${n}`, icon: 'palette', group: 'settings', keywords: ['colour', 'color', 'theme', n], run: () => setPrefs({ accent: a, accent2: a2 }) })),
    { id: 'font-up', label: 'Bigger text', icon: 'type', group: 'settings', keywords: ['font size', 'increase', 'larger', 'zoom in'], run: () => bumpFont(0.08) },
    { id: 'font-down', label: 'Smaller text', icon: 'type', group: 'settings', keywords: ['font size', 'decrease', 'zoom out'], run: () => bumpFont(-0.08) },
    { id: 'font-reset', label: 'Reset text size', icon: 'type', group: 'settings', keywords: ['font size', 'default'], run: () => setPrefs({ fontScale: 1 }) },
    { id: 'motion', label: 'Reduce motion', icon: 'activity', group: 'settings', keywords: ['animations', 'accessibility'], active: () => !!state.prefs.reduceMotion, run: () => setPrefs({ reduceMotion: !state.prefs.reduceMotion }) },
    { id: 'captions-lang', label: 'Caption language', icon: 'captions', group: 'settings', keywords: ['transcript language', 'yoruba', 'igbo', 'hausa', 'pidgin'], run: go('/settings#captions'), when: () => !state.inRoom },
    { id: 'install', label: 'Install 1venue app', short: 'Install', icon: 'install', group: 'nav', keywords: ['pwa', 'add to home screen'], run: promptInstall },
    { id: 'shortcuts', label: 'Keyboard shortcuts', icon: 'keyboard', group: 'nav', keywords: ['hotkeys', 'keys', 'help'], run: showShortcuts },
    { id: 'login', label: 'Sign in', icon: 'login', group: 'nav', keywords: ['log in', 'account', 'google'], when: () => !state.user, run: () => goLogin() },
    { id: 'signup', label: 'Create account', icon: 'user', group: 'nav', keywords: ['sign up', 'register', 'join'], when: () => !state.user, run: () => goLogin(undefined, { signup: true }) },
    { id: 'admin', label: 'Admin: demo data, plans', icon: 'shield', group: 'admin', keywords: ['seed', 'sample', 'demo'], when: () => !!state.user?.isAdmin, run: go('/admin') },
    { id: 'logout', label: 'Sign out', icon: 'logout', group: 'admin', keywords: ['log out'], when: () => !!state.user, run: logout },
  ];
  registerCommands('global', GLOBAL);
}
export function joinPrompt() {
  const s = sheet({ title: 'Join a room', icon: 'login', group: 'people' });
  const inp = h('input', { class: 'input code-big', placeholder: 'y5yi87', maxlength: 8, autocapitalize: 'none', autocomplete: 'off', spellcheck: 'false', style: { textAlign: 'center' } });
  const go = () => { const c = parseCode(inp.value); if (!c) return toast('Codes look like y5yi87', { icon: 'info' }); s.close(); navigate(`/${c}`); };
  inp.addEventListener('keydown', (e) => e.key === 'Enter' && go());
  s.body.append(h('p', { class: 'muted small', style: { marginBottom: '.8rem' } }, 'Enter the 6-character room code (letters and numbers, any case).'), inp, h('button', { class: 'btn primary block', style: { marginTop: '1rem' }, onclick: go }, 'Continue'));
}
function showShortcuts() {
  const rows = [['/ or Ctrl K', 'Focus the command bar'], ['↑ ↓ ← →', 'Move between suggested actions'], ['Enter', 'Run action / search everything'], ['Esc', 'Close sheet or clear the bar'], ['In a room: M', 'Mute / unmute'], ['In a room: V', 'Camera on / off'], ['In a room: H', 'Raise / lower hand'], ['In a room: C', 'Chat']];
  const s = sheet({ title: 'Keyboard shortcuts', icon: 'keyboard' });
  s.body.append(h('div', { class: 'layer' }, rows.map(([k, d]) => h('div', { class: 'set-row' }, h('span', { class: 'kbd' }, k), h('span', { class: 'grow muted' }, d)))));
}

/* ---------- boot ---------- */
async function boot() {
  state.prefs = loadLocalPrefs(); applyPrefs();
  buildShell(); initTooltips(); registerGlobal();
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href]');
    if (!a || a.target || a.hasAttribute('download') || e.metaKey || e.ctrlKey || e.shiftKey) return;
    const url = new URL(a.href, location.href);
    if (url.origin !== location.origin || url.pathname.startsWith('/api/') || url.pathname.startsWith('/files/') || url.pathname.startsWith('/auth/') || /^\/(privacy|terms)(\.html)?\/?$/.test(url.pathname)) return;
    e.preventDefault();
    if (/^\/create\/?$/.test(url.pathname) && url.searchParams.get('instant') && !state.inRoom) return openInstantOverlay(); // over the current page
    if (/^\/(login|forgot-password)\/?$/.test(url.pathname) && !state.inRoom) { // log in opens as an overlay
      const p = Object.fromEntries(url.searchParams);
      return goLogin(p.next || location.pathname + location.search, { mode: url.pathname.startsWith('/forgot') || p.mode === 'forgot' ? 'forgot' : 'login' });
    }
    navigate(url.pathname + url.search + url.hash);
  });
  window.addEventListener('popstate', route);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeTopSheet(); });
  try { state.config = await api('/api/config'); } catch { state.config = { features: {}, media: {} }; }
  await refreshSession();
  await route();
  initPwa();
  import('./voice.js').then((m) => m.initVoice()).catch(() => {}); // voice typing in every eligible text box
  if ('serviceWorker' in navigator && location.protocol !== 'file:') navigator.serviceWorker.register('/sw.js').catch(() => {});
}
if (!window.__1venueBooted) { window.__1venueBooted = true; boot(); }
export { focusBar, barVisible, toastErr };
